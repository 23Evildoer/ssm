CREATE procedure  getsf(
eno in number,v_ename out varchar2)
is 
begin 
  select ename into v_ename from emp where empno = eno;
  end;
/

