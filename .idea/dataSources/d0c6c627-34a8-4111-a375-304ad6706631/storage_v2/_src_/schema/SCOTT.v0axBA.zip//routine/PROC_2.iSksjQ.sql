CREATE procedure proc_2(v_empno in number,v_ename out varchar2)
as
begin
 select ename into v_ename from emp where empno=v_empno;
 end;
/

