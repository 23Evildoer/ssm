CREATE TRIGGER TR_IS
  BEFORE UPDATE
  ON EMP_TEMP
  FOR EACH ROW
  begin 
   if(:new.sal<:old.sal) then
   raise_application_error(-20000,'无法修改');
   end if;
   end;
/

