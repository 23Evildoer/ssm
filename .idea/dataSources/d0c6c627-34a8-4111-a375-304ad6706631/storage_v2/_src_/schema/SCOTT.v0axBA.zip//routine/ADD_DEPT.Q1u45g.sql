CREATE procedure add_dept(dept_no in number,dept_name in varchar2)
as
  begin
     insert into dept(deptno,dname) values(dept_no,dept_name);
   end ;
/

