CREATE procedure proc_1(eno in number,v_sal out number)
as
  begin
    select sal into v_sal from emp where empno=eno;
    dbms_output.put_line(eno||'编号员工的工资是:'||v_sal);
  end;
/

