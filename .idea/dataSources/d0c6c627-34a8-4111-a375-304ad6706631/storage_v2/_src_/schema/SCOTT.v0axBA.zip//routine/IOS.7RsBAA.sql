CREATE procedure ios(enos in out number)
as
begin
select sal into enos from emp where empno=enos;
end;
/

