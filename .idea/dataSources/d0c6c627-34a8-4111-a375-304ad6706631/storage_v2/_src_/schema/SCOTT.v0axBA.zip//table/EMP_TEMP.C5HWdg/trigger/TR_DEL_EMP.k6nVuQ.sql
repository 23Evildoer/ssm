CREATE TRIGGER TR_DEL_EMP
  BEFORE DELETE
  ON EMP_TEMP
  FOR EACH ROW
  begin
     --插入数据
    insert into emp_his(empno,ename,job,mgr,hiredate,sal,comm,deptno) values
    (:old.empno,:old.ename,:old.job,:old.mgr,:old.hiredate,:old.sal,:old.comm,:old.deptno); 
    end;
/

