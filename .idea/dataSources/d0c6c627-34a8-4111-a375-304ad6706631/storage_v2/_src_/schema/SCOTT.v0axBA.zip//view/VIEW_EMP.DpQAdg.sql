CREATE VIEW VIEW_EMP AS
  select empno,ename,sal from emp
/

